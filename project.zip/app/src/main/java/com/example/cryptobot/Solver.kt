package com.example.cryptobot

import android.content.Context

/** Cryptogram solver: words = list of number arrays, known[n] = letter(1..26) or 0. */
object Solver {
    private var common: Map<Int, List<String>> = emptyMap()
    private var full: Map<Int, List<String>> = emptyMap()
    val ready get() = common.isNotEmpty()

    private fun rd(ctx: Context, f: String): Map<Int, List<String>> =
        ctx.assets.open(f).bufferedReader().useLines { l ->
            l.map { it.trim().uppercase() }
                .filter { w -> w.isNotEmpty() && w.length <= 20 && w.all { it in 'A'..'Z' } && (w.length > 1 || w == "A" || w == "I") }
                .distinct().toList().groupBy { it.length }
        }

    fun load(ctx: Context) { common = rd(ctx, "common.txt"); full = rd(ctx, "full.txt") }

    fun solve(words: List<IntArray>, known: IntArray, banned: Set<Int>): IntArray? =
        attempt(words, known, banned, common, 20000, 4000) ?: attempt(words, known, banned, full, 3000, 6000)

    private fun attempt(words: List<IntArray>, known: IntArray, banned: Set<Int>,
                        dict: Map<Int, List<String>>, maxNodes: Int, ms: Long): IntArray? {
        val a = known.copyOf()
        val used = IntArray(27)
        for (n in 1..26) if (a[n] != 0) used[a[n]] = n
        for (w in words) for (code in w) if (code < 0 && used[-code] == 0) used[-code] = 27
        var nodes = 0
        val end = System.currentTimeMillis() + ms

        fun fits(w: String, nums: IntArray): Boolean {
            val nl = IntArray(27); val ln = IntArray(27)
            for (i in nums.indices) {
                val code = nums[i]; val c = w[i] - 'A' + 1
                if (code < 0) { if (-code != c) return false; continue }
                val n = code
                if (a[n] != 0) { if (a[n] != c) return false; continue }
                if (nl[n] != 0 && nl[n] != c) return false
                if (ln[c] != 0 && ln[c] != n) return false
                if (used[c] != 0) return false
                if (banned.contains(n * 32 + c)) return false
                nl[n] = c; ln[c] = n
            }
            return true
        }

        fun rec(): Boolean {
            if (++nodes > maxNodes || System.currentTimeMillis() > end) return false
            var bw: IntArray? = null
            var bc: List<String>? = null
            for (w in words) {
                if (w.all { it < 0 || a[it] != 0 }) continue
                val c = (dict[w.size] ?: return false).filter { fits(it, w) }
                if (c.isEmpty()) return false
                if (bc == null || c.size < bc.size) { bw = w; bc = c }
            }
            if (bw == null || bc == null) return true
            for (c in bc) {
                val set = ArrayList<Int>()
                for (i in bw.indices) {
                    val n = bw[i]
                    if (n > 0 && a[n] == 0) { a[n] = c[i] - 'A' + 1; used[a[n]] = n; set.add(n) }
                }
                if (rec()) return true
                for (n in set) { used[a[n]] = 0; a[n] = 0 }
            }
            return false
        }
        return if (rec()) a else null
    }
}
