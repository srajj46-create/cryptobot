package com.example.cryptobot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class Cell(val n: Int, val x: Int, val y: Int, var ch: Char = ' ')

class BotService : AccessibilityService() {
    private lateinit var btn: Button
    @Volatile private var running = false
    private val ui = Handler(Looper.getMainLooper())
    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val banned = HashSet<Int>()
    private val fails = HashMap<Int, Int>()
    private val typed = HashMap<Int, Int>()

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        Thread { Solver.load(this) }.start()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        btn = Button(this).apply { text = "▶ BOT"; setOnClickListener { toggle() } }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = (resources.displayMetrics.heightPixels * 0.60).toInt() }
        wm.addView(btn, lp)
    }

    private fun status(s: String) { ui.post { btn.text = s } }

    private fun toggle() {
        running = !running
        if (running) Thread { loop() }.start() else status("▶ BOT")
    }

    private fun loop() {
        var unknown = 0
        while (running) {
            try {
                if (!Solver.ready) { status("loading words..."); Thread.sleep(1000); continue }
                val bmp = shot()
                if (bmp == null) { Thread.sleep(600); continue }
                val w = bmp.width; val h = bmp.height
                clean(bmp)
                val t = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
                val els = t.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                val low = { e: Text.Element -> (e.boundingBox?.centerY() ?: 0) > 0.6 * h }
                val next = els.firstOrNull { it.text.equals("NEXT", true) && low(it) }
                val start = els.firstOrNull { it.text.uppercase().startsWith("STA") && low(it) }
                val inGame = els.any { it.text.contains("istake") }
                when {
                    next != null -> { reset(); unknown = 0; status("NEXT"); tap(next.boundingBox!!.centerX().toFloat(), next.boundingBox!!.centerY().toFloat()); Thread.sleep(1500) }
                    start != null -> { reset(); unknown = 0; status("START"); tap(start.boundingBox!!.centerX().toFloat(), start.boundingBox!!.centerY().toFloat()); Thread.sleep(1500) }
                    inGame -> { unknown = 0; play(els, w, h); Thread.sleep(400) }
                    else -> { status("unknown screen"); if (++unknown >= 5) { performGlobalAction(GLOBAL_ACTION_BACK); unknown = 0 }; Thread.sleep(1000) }
                }
            } catch (e: Exception) { status("err: ${e.javaClass.simpleName}"); Thread.sleep(1000) }
        }
        status("▶ BOT")
    }

    private fun reset() { banned.clear(); fails.clear(); typed.clear() }

    private fun play(els: List<Text.Element>, w: Int, h: Int) {
        val s = w / 1080f
        val cells = parse(els, w, h, s)
        if (cells.size < 5) { status("cells=${cells.size}"); return }
        val known = IntArray(27)
        cells.forEach { if (it.ch != ' ') known[it.n] = it.ch - 'A' + 1 }
        val empty = cells.filter { it.ch == ' ' }.map { it.n }.toSet()
        if (empty.isEmpty()) { status("done, waiting NEXT"); return }
        for ((n, c) in typed) if (n in empty) {
            val k = n * 32 + c; fails[k] = (fails[k] ?: 0) + 1
            if (fails[k]!! >= 2) banned.add(k)
        }
        typed.clear()
        // group cells into rows, then words (gap > 100px = word break)
        val rows = ArrayList<ArrayList<Cell>>()
        for (c in cells.sortedBy { it.y }) {
            if (rows.isNotEmpty() && abs(rows.last().first().y - c.y) < 40 * s) rows.last().add(c) else rows.add(arrayListOf(c))
        }
        val words = ArrayList<IntArray>()
        for (r in rows) {
            val cur = ArrayList<Int>(); var px = -9999
            for (c in r.sortedBy { it.x }) {
                if (cur.isNotEmpty() && c.x - px > 100 * s) { words.add(cur.toIntArray()); cur.clear() }
                cur.add(c.n); px = c.x
            }
            if (cur.isNotEmpty()) words.add(cur.toIntArray())
        }
        status("cells=${cells.size} empty=${empty.size} solving")
        val sol = Solver.solve(words, known, banned)
        if (sol == null) { status("cannot solve"); return }
        for (n in empty) {
            val c = sol[n]; if (c == 0) continue
            val cell = cells.first { it.n == n && it.ch == ' ' }
            tap(cell.x.toFloat(), cell.y - 60 * s)
            val k = keyXY('A' + (c - 1), w, h)
            tap(k.first, k.second)
            typed[n] = c
            Thread.sleep(200)
        }
    }

    private fun parse(els: List<Text.Element>, w: Int, h: Int, s: Float): List<Cell> {
        val cells = ArrayList<Cell>()
        for (e in els) {
            val bb = e.boundingBox ?: continue
            val t = e.text.trim()
            if (t.length in 1..2 && t.all { it.isDigit() }) {
                val v = t.toInt()
                if (v in 1..26 && !(bb.centerX() > 0.78 * w && bb.centerY() > 0.58 * h) && bb.centerY() < 0.66 * h)
                    cells.add(Cell(v, bb.centerX(), bb.centerY()))
            }
        }
        for (e in els) {
            val bb = e.boundingBox ?: continue
            val t = e.text
            for ((i, c) in t.withIndex()) if (c in 'A'..'Z') {
                val cx = bb.left + (i + 0.5f) * bb.width() / t.length
                val cy = bb.centerY()
                val cell = cells.filter { abs(it.x - cx) < 0.55f * 62 * s && (it.y - cy) in (30 * s)..(150 * s) }
                    .minByOrNull { abs(it.x - cx) }
                if (cell != null && cell.ch == ' ') cell.ch = c
            }
        }
        return cells
    }

    private fun keyXY(c: Char, w: Int, h: Int): Pair<Float, Float> {
        val rows = arrayOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        val x0 = floatArrayOf(62f, 109f, 221f); val dx = floatArrayOf(106f, 107.5f, 106f)
        val y = floatArrayOf(1757f, 1902f, 2047f)
        for (r in 0..2) { val i = rows[r].indexOf(c); if (i >= 0) return Pair((x0[r] + dx[r] * i) / 1080f * w, y[r] / 2408f * h) }
        return Pair(0f, 0f)
    }

    // replace the bright-green "selected cell" highlight by the background so OCR can read the number
    private fun clean(b: Bitmap) {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        for (i in px.indices) {
            val c = px[i]; val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            if (g > 215 && r < 140 && bl < 70) px[i] = 0xFFF7F2F0.toInt()
        }
        b.setPixels(px, 0, b.width, 0, 0, b.width, b.height)
    }

    private fun shot(): Bitmap? {
        val latch = CountDownLatch(1); var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, true)
                hb.close(); latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(3, TimeUnit.SECONDS)
        return out
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val l = CountDownLatch(1)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { l.countDown() }
                override fun onCancelled(g: GestureDescription?) { l.countDown() }
            }, null)
        l.await(2, TimeUnit.SECONDS)
        Thread.sleep(120)
    }
}
