package com.example.cryptobot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "1) Button dabao -> Accessibility -> CryptoBot ON karo.\n" +
                "(Agar blocked ho: Settings > Apps > CryptoBot > ⋮ > Allow restricted settings)\n\n" +
                "2) Cryptogram game kholo (home screen ya level screen).\n\n" +
                "3) Screen par floating '▶ BOT' button dabao. Dobara dabao to STOP."
        })
        l.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(l)
    }
}
